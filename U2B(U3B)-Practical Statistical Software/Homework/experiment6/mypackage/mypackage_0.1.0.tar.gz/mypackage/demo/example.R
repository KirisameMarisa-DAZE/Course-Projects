# Demo script for mypackage
# This script demonstrates how to use my_function

# Load the package
library(mypackage)

# Use the function
result <- my_function(3, 4)
print(result)